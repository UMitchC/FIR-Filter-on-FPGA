clc;
close all;
clear all;
Fs  = 5000;   %System sampling rate
Fc1 = 100;
Fc2 = 2000;

T = 4;
t = 0 :1/Fs: T/Fc1;

y1 = sin(2*pi*Fc1*t);
y2 = sin(2*pi*Fc2*t);
figure(1);
subplot(311);
plot(t,y1,'r');
title('Time domain waveform'); xlabel('Time(s)');    ylabel('Amplitude');  
subplot(312);
plot(t,y2,'r');
title('Time domain waveform'); xlabel('Time(s)');    ylabel('Amplitude');  

y3 = y1 + y2;
subplot(313);
plot(t,y3,'r');
title('Time domain waveform'); xlabel('Time (s)');    ylabel('Amplitude');  

%% low pass filter %%
Fc_lpf=1000; 
Wc=Fc_lpf*2/Fs; %Normalized passband cutoff frequency
hd = fir1(7,Wc,'low') %Low pass filter
figure(2);
subplot(211);
freqz(hd,1,512);

subplot(212);
y3_fir_lpf = conv(y3,hd);%Convolution
plot(y3_fir_lpf,'r');
title('Time domain waveform'); xlabel('Time (s)');    ylabel('Amplitude');    


%% Data storage, fpga reading operations%%

T = 1000;
t = 0 :1/Fs: T/Fc1;

y1_s = sin(2*pi*Fc1*t);
y2_s = sin(2*pi*Fc2*t);

y3_s = y1_s + y2_s;
Q=16;
y3_g=y3_s/max(abs(y3_s));%Normalized processing
Q_s=round(y3_g*(2^(Q-1)-1));

fid = fopen('sinf1f2.data','w');

for i=1:length(y3_s)
   B_s=dec2bin(Q_s(i)+(Q_s(i)<0)*2^Q,Q); %decimal covert to binary% 
    for j=1:Q
       if B_s(j)=='1'
           tb=1;
       else
           tb=0;
       end
       fprintf(fid,'%d',tb);  
    end
   fprintf(fid, '\n');
end
fclose(fid);

%% Low-pass filter parameter storage storage, fpga read operation%%

Q=8;
hd_g=hd/max(abs(hd));%��һ������
Q_s=round(hd_g*(2^(Q-1)-1))

fid = fopen('firlpf.data','w');

for i=1:length(hd)
   B_s=dec2bin(Q_s(i)+(Q_s(i)<0)*2^Q,Q);
    for j=1:Q
       if B_s(j)=='1'
           tb=1;
       else
           tb=0;
       end
       fprintf(fid,'%d',tb);  
    end
   fprintf(fid, '\n');%new line%
end
fclose(fid);


